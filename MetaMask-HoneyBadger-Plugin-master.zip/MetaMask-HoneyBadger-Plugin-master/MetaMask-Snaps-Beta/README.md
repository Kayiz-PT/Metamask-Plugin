# MetaMask Snaps Beta

Welcome to the MetaMask Snaps Beta. This repository is a fork of the regular MetaMask extension, which you can find [here](https://github.com/MetaMask/metamask-extension/).

MetaMask Snaps is the name for our [plugin system](https://medium.com/metamask/introducing-the-next-evolution-of-the-web3-wallet-4abdf801a4ee). Everything you need to know can be found in [the MetaMask Snaps Wiki](https://github.com/MetaMask/metamask-snaps-beta/wiki).

![MetaMask Snaps Logo](https://miro.medium.com/max/1492/1*3rV0z0ufTqkGC4RJ3vXQwA.png)
