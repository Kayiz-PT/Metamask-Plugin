export { default } from './dai-migration-notification.container'
