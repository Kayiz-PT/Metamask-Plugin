export { default } from './confirm-detail-row.component'
