const NetworkController = require('./network')
module.exports = NetworkController
